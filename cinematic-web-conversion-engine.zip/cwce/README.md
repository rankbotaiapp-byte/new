# Cinematic Web-Conversion Engine
`npm install && npm run dev` then open http://localhost:3000 (dashboard) and /embed?city=Austin&service=Solar (widget).
Not yet built: auth, DB-stored configs per user-id, real lead capture, video rendering, image storage. Config currently travels in the script tag (data-cfg).
