/* Cinematic Hero embed: <script src=".../widget.js" data-user-id="..." data-cfg="..." defer></script> */
(function () {
  var s = document.currentScript; if (!s) return;
  var origin = new URL(s.src).origin, host = new URLSearchParams(location.search);
  var q = new URLSearchParams({ uid: s.dataset.userId || "" });
  if (s.dataset.cfg) q.set("cfg", s.dataset.cfg);
  ["city", "service"].forEach(function (k) { if (host.get(k)) q.set(k, host.get(k)); });
  var f = document.createElement("iframe");
  f.src = origin + "/embed?" + q; f.title = "Hero"; f.loading = "lazy";
  f.style.cssText = "width:100%;height:640px;border:0;display:block";
  s.parentNode.insertBefore(f, s);
})();
