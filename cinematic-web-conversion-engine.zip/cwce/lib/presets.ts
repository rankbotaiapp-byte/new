import type { GradeId, HeroConfig } from "./types";
export const GRADES: Record<GradeId, { label: string; bg: string; glow: string; particle: string }> = {
  golden: { label: "Golden Hour", bg: "radial-gradient(60% 50% at 30% 30%,#f2b45a88,transparent),radial-gradient(50% 60% at 80% 70%,#c2410c66,transparent),#2a1608", glow: "#f2b45a", particle: "#ffd89a" },
  moody: { label: "Moody Cinematic", bg: "radial-gradient(60% 50% at 25% 35%,#3b6ea855,transparent),radial-gradient(50% 60% at 75% 70%,#1e293b,transparent),#0a1018", glow: "#6aa5d8", particle: "#b7d3ee" },
  neon: { label: "Neon Cyberpunk", bg: "radial-gradient(55% 50% at 25% 30%,#ff2fa088,transparent),radial-gradient(55% 60% at 80% 70%,#22d3ee77,transparent),#12061f", glow: "#ff2fa0", particle: "#7ff3ff" },
};
export const NICHES: Record<string, { hook: string; options: string[]; base: number }> = {
  "Luxury Real Estate": { hook: "Homes that sell before the sign goes up", options: ["Sell", "Buy", "Valuation"], base: 2500 },
  Fitness: { hook: "Your strongest season starts here", options: ["Personal training", "Group classes", "Nutrition"], base: 180 },
  Roofing: { hook: "A roof built to outlast the storm", options: ["Repair", "Replacement", "Inspection"], base: 6500 },
  SaaS: { hook: "Ship faster with fewer tools", options: ["Starter", "Team", "Enterprise"], base: 49 },
};
export const DEFAULT_CONFIG: HeroConfig = { businessName: "Northlight Roofing", niche: "Roofing", grade: "golden", loopSeconds: 3, motion: 60, particles: true, particleCount: 24, vignette: 65 };
const SERVICE_GRADE: Record<string, GradeId> = { solar: "golden", roofing: "golden", fitness: "neon", gym: "neon", saas: "neon", software: "neon", legal: "moody", realestate: "moody" };
export const gradeForService = (s?: string | null): GradeId | undefined => (s ? SERVICE_GRADE[s.toLowerCase().replace(/\s/g, "")] : undefined);
