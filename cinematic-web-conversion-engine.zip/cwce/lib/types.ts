export type GradeId = "golden" | "moody" | "neon";
export interface HeroConfig {
  businessName: string; niche: string; grade: GradeId;
  loopSeconds: number; motion: number; particles: boolean; particleCount: number; vignette: number;
  logoUrl?: string; headshotUrl?: string;
}
export interface Scene { time: string; visual: string; caption: string }
export type Platform = "TikTok" | "Instagram Reels" | "YouTube Shorts";
