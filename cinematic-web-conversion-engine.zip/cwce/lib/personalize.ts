import type { HeroConfig } from "./types";
import { NICHES, gradeForService } from "./presets";
export interface Personalized { headline: string; sub: string; config: HeroConfig; personalized: boolean }
/** Reads ?city=Austin&service=Solar and adapts headline + theme. */
export function personalize(config: HeroConfig, p: { get(k: string): string | null }): Personalized {
  const city = p.get("city")?.trim().slice(0, 40), service = p.get("service")?.trim().slice(0, 40);
  const hook = NICHES[config.niche]?.hook ?? "Built to convert";
  const headline = service && city ? `${service} in ${city}, done right` : service ? `${service} that actually delivers` : city ? `${hook} in ${city}` : hook;
  const grade = gradeForService(service) ?? config.grade;
  return { headline, sub: `${config.businessName}${city ? ` serves ${city}` : ""}. Get your instant estimate in 30 seconds.`, config: { ...config, grade }, personalized: !!(city || service) };
}
