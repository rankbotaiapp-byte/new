import type { HeroConfig, Platform, Scene } from "./types";
export function buildStoryboard(platform: Platform, c: HeroConfig): Scene[] {
  const len = platform === "YouTube Shorts" ? 45 : platform === "Instagram Reels" ? 30 : 20;
  const at = (f: number) => `0:${String(Math.round(len * f)).padStart(2, "0")}`;
  return [
    { time: `0:00`, visual: "Static template site, scroll jitter, bounce-rate counter climbing", caption: `Your ${c.niche.toLowerCase()} website is losing 7 of 10 visitors.` },
    { time: at(0.2), visual: "Hard cut. Same page, flat hero, one stock photo", caption: "Visitors decide in 3 seconds. This gives them nothing to feel." },
    { time: at(0.4), visual: `Whip transition into cinematic ${c.grade} loop with drifting particles`, caption: "Now watch the same page." },
    { time: at(0.6), visual: "Headline swaps to ?city= visitor intent, quiz card glows in", caption: "It speaks to each visitor by city and service." },
    { time: at(0.8), visual: "Booking toast pops, lead counter ticks up", caption: "Real bookings, same traffic." },
    { time: `0:${len}`, visual: `${c.businessName} logo end card, link-in-bio arrow`, caption: "Get your cinematic hero live in minutes. Link in bio." },
  ];
}
