"use client";
import { useEffect, useState } from "react";
const CITIES = ["Austin", "Medford", "Denver", "Tampa", "Boise"], ACTS = ["booked an estimate", "requested a quote", "started a free consult"];
export default function SocialProofToasts({ brand }: { brand: string }) {
  const [i, setI] = useState(0);
  useEffect(() => { const t = setInterval(() => setI((x) => x + 1), 5000); return () => clearInterval(t); }, []);
  return (
    <div className="pointer-events-none absolute bottom-4 left-4 z-20" aria-live="polite">
      <div key={i} className="flex items-center gap-2 rounded-full border border-white/15 bg-black/60 px-3 py-2 text-xs backdrop-blur-md" style={{ animation: "toast 5s ease both" }}>
        <span className="size-2 rounded-full bg-emerald-400" />Someone in {CITIES[i % CITIES.length]} {ACTS[i % ACTS.length]} with {brand}
      </div>
    </div>
  );
}
