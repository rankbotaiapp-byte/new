"use client";
import { useState } from "react";
import type { HeroConfig, Platform } from "@/lib/types";
import { buildStoryboard } from "@/lib/storyboard";
import { Panel } from "../ui/controls";
const PLATFORMS: Platform[] = ["TikTok", "Instagram Reels", "YouTube Shorts"];
export default function StoryboardGenerator({ config }: { config: HeroConfig }) {
  const [pf, setPf] = useState<Platform>("TikTok"); const scenes = buildStoryboard(pf, config);
  const copy = () => navigator.clipboard.writeText(scenes.map((s) => `${s.time} | ${s.visual}\n   "${s.caption}"`).join("\n"));
  return (
    <Panel title="Before & after ad storyboard">
      <div className="flex flex-wrap gap-2">{PLATFORMS.map((p) => (<button key={p} onClick={() => setPf(p)} className={`rounded-lg border px-3 py-1.5 text-sm ${pf === p ? "border-film text-film" : "border-line text-zinc-400"}`}>{p}</button>))}
        <button onClick={copy} className="ml-auto rounded-lg bg-film px-3 py-1.5 text-sm font-medium text-black">Copy storyboard</button></div>
      <ol className="grid gap-3 md:grid-cols-3">{scenes.map((s) => (
        <li key={s.time} className="rounded-xl border border-line bg-ink p-3 text-sm"><p className="text-film">{s.time}</p><p className="mt-1 text-zinc-300">{s.visual}</p><p className="mt-2 font-display text-base">&ldquo;{s.caption}&rdquo;</p></li>))}</ol>
    </Panel>
  );
}
