"use client";
export const Panel = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <section className="rounded-2xl border border-line bg-panel p-5"><h2 className="mb-4 font-display text-lg">{title}</h2><div className="space-y-4">{children}</div></section>
);
export const Field = ({ label, children }: { label: string; children: React.ReactNode }) => (
  <label className="block text-sm text-zinc-400"><span className="mb-1.5 block">{label}</span>{children}</label>
);
export const inputCls = "w-full rounded-lg border border-line bg-ink px-3 py-2 text-zinc-100 outline-none focus:border-film focus-visible:ring-2 focus-visible:ring-film/40";
export function Slider({ label, value, min, max, step = 1, unit = "", onChange }: { label: string; value: number; min: number; max: number; step?: number; unit?: string; onChange: (v: number) => void }) {
  return (<Field label={`${label}: ${value}${unit}`}><input type="range" className="w-full accent-[#f2b45a]" {...{ min, max, step, value }} onChange={(e) => onChange(+e.target.value)} /></Field>);
}
