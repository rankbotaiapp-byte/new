"use client";
import type { GradeId, HeroConfig } from "@/lib/types";
import { GRADES } from "@/lib/presets";
import { Panel, Slider } from "../ui/controls";
export default function VisualControls({ config, set }: { config: HeroConfig; set: (p: Partial<HeroConfig>) => void }) {
  return (
    <Panel title="Cinematic look">
      <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label="Lighting grade">
        {(Object.keys(GRADES) as GradeId[]).map((g) => (
          <button key={g} role="radio" aria-checked={config.grade === g} onClick={() => set({ grade: g })}
            className={`rounded-lg border px-2 py-3 text-xs ${config.grade === g ? "border-film bg-film/10 text-film" : "border-line text-zinc-400"}`}>{GRADES[g].label}</button>
        ))}
      </div>
      <Slider label="Loop length" value={config.loopSeconds} min={2} max={8} unit="s" onChange={(v) => set({ loopSeconds: v })} />
      <Slider label="Motion" value={config.motion} min={0} max={100} unit="%" onChange={(v) => set({ motion: v })} />
      <Slider label="Vignette" value={config.vignette} min={0} max={100} unit="%" onChange={(v) => set({ vignette: v })} />
      <label className="flex items-center gap-2 text-sm text-zinc-300"><input type="checkbox" className="accent-[#f2b45a]" checked={config.particles} onChange={(e) => set({ particles: e.target.checked })} />Atmospheric particles</label>
      {config.particles && <Slider label="Particle count" value={config.particleCount} min={6} max={60} onChange={(v) => set({ particleCount: v })} />}
    </Panel>
  );
}
