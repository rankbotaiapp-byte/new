"use client";
import type { HeroConfig } from "@/lib/types";
import { NICHES } from "@/lib/presets";
import { Panel, Field, inputCls } from "../ui/controls";
export default function AssetSetup({ config, set }: { config: HeroConfig; set: (p: Partial<HeroConfig>) => void }) {
  const upload = (key: "logoUrl" | "headshotUrl") => (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]; if (f) set({ [key]: URL.createObjectURL(f) });
  };
  return (
    <Panel title="Brand assets">
      <Field label="Business name"><input className={inputCls} value={config.businessName} onChange={(e) => set({ businessName: e.target.value })} /></Field>
      <Field label="Niche"><select className={inputCls} value={config.niche} onChange={(e) => set({ niche: e.target.value })}>{Object.keys(NICHES).map((n) => <option key={n}>{n}</option>)}</select></Field>
      <Field label="Logo"><input type="file" accept="image/*" className={inputCls} onChange={upload("logoUrl")} /></Field>
      <Field label="Headshot"><input type="file" accept="image/*" className={inputCls} onChange={upload("headshotUrl")} /></Field>
    </Panel>
  );
}
