"use client";
import { Suspense, useMemo, useState } from "react";
import type { HeroConfig } from "@/lib/types";
import HeroWidget from "../hero/HeroWidget";
import { inputCls } from "../ui/controls";
export default function PreviewStage({ config }: { config: HeroConfig }) {
  const [mobile, setMobile] = useState(false); const [city, setCity] = useState("Austin"); const [service, setService] = useState("Solar");
  const params = useMemo(() => { const p = new URLSearchParams(); if (city) p.set("city", city); if (service) p.set("service", service); return p; }, [city, service]);
  return (
    <section className="rounded-2xl border border-line bg-panel p-5">
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <h2 className="mr-auto font-display text-lg">Live preview</h2>
        <input aria-label="Visitor city" className={`${inputCls} !w-28`} value={city} onChange={(e) => setCity(e.target.value)} placeholder="?city=" />
        <input aria-label="Visitor service" className={`${inputCls} !w-28`} value={service} onChange={(e) => setService(e.target.value)} placeholder="?service=" />
        {["Desktop", "Mobile"].map((d) => (<button key={d} onClick={() => setMobile(d === "Mobile")} className={`rounded-lg border px-3 py-1.5 text-sm ${mobile === (d === "Mobile") ? "border-film text-film" : "border-line text-zinc-400"}`}>{d}</button>))}
      </div>
      <div className={`mx-auto overflow-hidden rounded-xl border border-line transition-[max-width] duration-300 ${mobile ? "max-w-[390px]" : "max-w-full"}`}>
        <Suspense fallback={null}><HeroWidget config={config} override={params} /></Suspense>
      </div>
    </section>
  );
}
