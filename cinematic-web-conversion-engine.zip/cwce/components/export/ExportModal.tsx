"use client";
import { useState } from "react";
import type { HeroConfig } from "@/lib/types";
export const encodeConfig = (c: HeroConfig) => btoa(unescape(encodeURIComponent(JSON.stringify({ ...c, logoUrl: undefined, headshotUrl: undefined }))));
export default function ExportModal({ config, onClose }: { config: HeroConfig; onClose: () => void }) {
  const [copied, setCopied] = useState(false);
  const tag = `<script src="${location.origin}/widget.js" data-user-id="usr_demo" data-cfg="${encodeConfig(config)}" defer></script>`;
  return (
    <div role="dialog" aria-modal aria-label="Export widget" className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4" onClick={onClose}>
      <div className="w-full max-w-xl rounded-2xl border border-line bg-panel p-6" onClick={(e) => e.stopPropagation()}>
        <h2 className="font-display text-xl">Embed on Webflow, WordPress, or any site</h2>
        <p className="mt-1 text-sm text-zinc-400">Paste this where the hero should appear. The visitor&apos;s ?city= and ?service= are read automatically.</p>
        <pre className="mt-4 max-h-40 overflow-auto whitespace-pre-wrap break-all rounded-lg border border-line bg-ink p-3 text-xs text-zinc-300">{tag}</pre>
        <div className="mt-4 flex justify-end gap-2">
          <button onClick={onClose} className="rounded-lg border border-line px-4 py-2 text-sm">Close</button>
          <button onClick={() => { navigator.clipboard.writeText(tag); setCopied(true); }} className="rounded-lg bg-film px-4 py-2 text-sm font-medium text-black">{copied ? "Copied" : "Copy script tag"}</button>
        </div>
      </div>
    </div>
  );
}
