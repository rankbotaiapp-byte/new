import type { HeroConfig } from "@/lib/types";
import { GRADES } from "@/lib/presets";
/** Seamless loop: keyframe start === end, so any loopSeconds repeats without a seam. */
export default function BackgroundEngine({ c }: { c: HeroConfig }) {
  const g = GRADES[c.grade], loop = c.loopSeconds;
  return (
    <div aria-hidden className="absolute inset-0 overflow-hidden">
      <div className="absolute -inset-[10%]" style={{ background: g.bg, animation: c.motion ? `drift ${loop}s ease-in-out infinite` : "none", opacity: 0.55 + c.motion / 250 }} />
      {c.particles && Array.from({ length: c.particleCount }, (_, i) => (
        <span key={i} className="absolute rounded-full" style={{
          left: `${(i * 37) % 100}%`, top: `${20 + ((i * 53) % 75)}%`, width: 2 + (i % 4), height: 2 + (i % 4),
          background: g.particle, boxShadow: `0 0 8px ${g.particle}`, animation: `rise ${loop * (1 + (i % 3))}s linear ${-(i * 0.37)}s infinite` }} />
      ))}
      <div className="absolute inset-0" style={{ background: `radial-gradient(ellipse at center,transparent ${70 - c.vignette / 2}%,rgba(0,0,0,${0.35 + c.vignette / 130}) 100%),linear-gradient(to top,rgba(0,0,0,.55),transparent 55%)` }} />
    </div>
  );
}
