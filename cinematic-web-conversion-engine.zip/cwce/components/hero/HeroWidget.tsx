"use client";
import { useSearchParams } from "next/navigation";
import type { HeroConfig } from "@/lib/types";
import { personalize } from "@/lib/personalize";
import BackgroundEngine from "./BackgroundEngine";
import ConversionGateway from "./ConversionGateway";
import SocialProofToasts from "../marketing/SocialProofToasts";
/** `override` lets the preview stage simulate query params without touching the URL. */
export default function HeroWidget({ config, override }: { config: HeroConfig; override?: URLSearchParams }) {
  const live = useSearchParams(); const p = personalize(config, override ?? live);
  return (
    <div className="@container relative isolate min-h-[520px] overflow-hidden bg-black text-white">
      <BackgroundEngine c={p.config} />
      <div className="relative z-10 grid items-center gap-8 p-6 @2xl:grid-cols-2 @2xl:p-12">
        <div>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          {p.config.logoUrl && <img src={p.config.logoUrl} alt="" className="mb-6 h-10 w-auto" />}
          <h1 className="font-display text-4xl leading-[1.05] @2xl:text-6xl">{p.headline}</h1>
          <p className="mt-4 max-w-md text-zinc-200">{p.sub}</p>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          {p.config.headshotUrl && <img src={p.config.headshotUrl} alt="" className="mt-6 size-14 rounded-full border border-white/30 object-cover" />}
        </div>
        <div className="flex @2xl:justify-end"><ConversionGateway c={p.config} /></div>
      </div>
      <SocialProofToasts brand={p.config.businessName} />
    </div>
  );
}
