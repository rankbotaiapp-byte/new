"use client";
import { useState } from "react";
import type { HeroConfig } from "@/lib/types";
import { GRADES, NICHES } from "@/lib/presets";
const SIZE = [{ l: "Small", m: 1 }, { l: "Medium", m: 1.6 }, { l: "Large", m: 2.4 }];
export default function ConversionGateway({ c }: { c: HeroConfig }) {
  const n = NICHES[c.niche]; const [step, setStep] = useState(1); const [opt, setOpt] = useState(n.options[0]); const [size, setSize] = useState(0);
  const [email, setEmail] = useState(""); const [done, setDone] = useState(false);
  const est = Math.round((n.base * SIZE[size].m) / 10) * 10; const glow = GRADES[c.grade].glow;
  const btn = "w-full rounded-xl px-4 py-2.5 text-sm font-medium text-black transition focus-visible:ring-2 focus-visible:ring-white";
  return (
    <div className="w-full max-w-sm rounded-2xl border bg-white/[.07] p-5 backdrop-blur-xl" style={{ borderColor: `${glow}66`, boxShadow: `0 0 40px ${glow}33, inset 0 0 0 1px #ffffff14` }}>
      {done ? (<div><p className="font-display text-xl">Estimate sent</p><p className="mt-1 text-sm text-zinc-300">We&apos;ll follow up at {email} within one business day.</p></div>) : step === 1 ? (
        <div className="space-y-3"><p className="text-xs text-zinc-300">Step 1 of 2</p><p className="font-display text-lg">What do you need?</p>
          {n.options.map((o) => (<button key={o} onClick={() => setOpt(o)} className={`w-full rounded-xl border px-3 py-2 text-left text-sm ${opt === o ? "border-white/70 bg-white/15" : "border-white/15"}`}>{o}</button>))}
          <button className={btn} style={{ background: glow }} onClick={() => setStep(2)}>Continue</button></div>
      ) : (
        <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); setDone(true); }}>
          <p className="text-xs text-zinc-300">Step 2 of 2</p><p className="font-display text-lg">{opt}: est. ${est.toLocaleString()}</p>
          <div className="flex gap-2">{SIZE.map((s, i) => (<button type="button" key={s.l} onClick={() => setSize(i)} className={`flex-1 rounded-lg border py-1.5 text-xs ${size === i ? "border-white/70 bg-white/15" : "border-white/15"}`}>{s.l}</button>))}</div>
          <input required type="email" placeholder="Email for your full quote" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full rounded-xl border border-white/20 bg-black/30 px-3 py-2 text-sm outline-none focus:border-white/60" />
          <button className={btn} style={{ background: glow }}>Send my estimate</button></form>)}
    </div>
  );
}
