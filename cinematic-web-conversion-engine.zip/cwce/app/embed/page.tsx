"use client";
import { Suspense } from "react";
import { useSearchParams } from "next/navigation";
import HeroWidget from "@/components/hero/HeroWidget";
import { DEFAULT_CONFIG } from "@/lib/presets";
function Embed() {
  const q = useSearchParams(); let cfg = DEFAULT_CONFIG;
  try { const raw = q.get("cfg"); if (raw) cfg = { ...DEFAULT_CONFIG, ...JSON.parse(decodeURIComponent(escape(atob(raw)))) }; } catch {}
  return <HeroWidget config={cfg} />;
}
export default function Page() { return <Suspense fallback={null}><Embed /></Suspense>; }
