"use client";
import { useState } from "react";
import type { HeroConfig } from "@/lib/types";
import { DEFAULT_CONFIG } from "@/lib/presets";
import AssetSetup from "@/components/studio/AssetSetup";
import VisualControls from "@/components/studio/VisualControls";
import PreviewStage from "@/components/studio/PreviewStage";
import StoryboardGenerator from "@/components/marketing/StoryboardGenerator";
import ExportModal from "@/components/export/ExportModal";
export default function Dashboard() {
  const [config, setConfig] = useState<HeroConfig>(DEFAULT_CONFIG); const [open, setOpen] = useState(false);
  const set = (p: Partial<HeroConfig>) => setConfig((c) => ({ ...c, ...p }));
  return (
    <main className="mx-auto max-w-7xl space-y-6 p-4 md:p-8">
      <header className="flex items-center justify-between">
        <h1 className="font-display text-2xl md:text-3xl">Cinematic Web-Conversion Engine</h1>
        <button onClick={() => setOpen(true)} className="rounded-lg bg-film px-4 py-2 text-sm font-medium text-black focus-visible:ring-2 focus-visible:ring-white">Export widget</button>
      </header>
      <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
        <div className="space-y-6"><AssetSetup config={config} set={set} /><VisualControls config={config} set={set} /></div>
        <PreviewStage config={config} />
      </div>
      <StoryboardGenerator config={config} />
      {open && <ExportModal config={config} onClose={() => setOpen(false)} />}
    </main>
  );
}
