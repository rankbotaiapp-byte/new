import type { Metadata } from "next";
import { Fraunces, Inter } from "next/font/google";
import "./globals.css";
const fraunces = Fraunces({ subsets: ["latin"], variable: "--font-fraunces" });
const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
export const metadata: Metadata = { title: "Cinematic Web-Conversion Engine" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en" className={`${fraunces.variable} ${inter.variable}`}><body>{children}</body></html>);
}
